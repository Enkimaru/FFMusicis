import { Component, Input, OnInit } from "@angular/core";
import { ActivatedRoute, Router } from '@angular/router';
import { MovieService } from './movie.service';

@Component({
    selector: 'app-movie',
    templateUrl: 'movie.component.html',
    styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit{
    @Input() movie ;
    
    constructor(
        private movieService: MovieService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    ) { }

    ngOnInit(): void {
        this.movie = this.movieService.getMovieById(this.activatedRoute.snapshot.params.id)[0];

        if (typeof this.movie == 'undefined') {
            console.log(this.movie);
            this.router.navigate(['/404'])
        }        
    }
}