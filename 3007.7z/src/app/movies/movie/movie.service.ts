import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

import MovieSessions from '../../../assets/MovieSessions.json';
import MovieList from '../../../assets/MovieList.json';

const API = 'http://localhost:3000';

@Injectable({ providedIn: 'root' })
export class MovieService {

    constructor(private http: HttpClient) {}

    listMovieSessions(){
        return MovieSessions;
    }

    getMovieById(id:number){
        return MovieList.filter(movie => (movie.id == id));
    }

    
}
