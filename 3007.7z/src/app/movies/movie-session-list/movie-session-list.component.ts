import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie/movie.service';
import { ActivatedRoute } from '@angular/router';
import { MovieSession } from '../movie-session/movie-session';

import moment from 'moment';
import 'moment/locale/br'
moment.locale('pt-BR')

@Component({
  selector: 'app-movie-session-list',
  templateUrl: './movie-session-list.component.html',
  styleUrls: ['./movie-session-list.component.css']
})

export class MovieSessionListComponent implements OnInit {
  movieSessions: MovieSession[] = []; 
  
  carouselOptions={items: 4, dots: true, nav: true};
  
  constructor(private movieService: MovieService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {

      this.movieSessions = this.listMovieSessions();

      
  }

  listMovieSessions(){

    let serviceMovieSessions = this.movieService.listMovieSessions();

    let sessions: MovieSession[] = [];

    serviceMovieSessions.forEach(movieSession => {
        let session = JSON.parse(JSON.stringify(movieSession));
       
        session.datetime = moment(movieSession.datetime).format('HH:mm');
        sessions.push(session);
   });

    return sessions;
  }
}
