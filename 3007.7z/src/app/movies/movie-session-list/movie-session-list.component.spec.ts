import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MovieSessionListComponent } from './movie-session-list.component';

describe('MovieSessionListComponent', () => {
  let component: MovieSessionListComponent;
  let fixture: ComponentFixture<MovieSessionListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MovieSessionListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MovieSessionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
