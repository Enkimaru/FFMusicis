import { Movie } from '../movie/movie';

export class MovieSession {
    id:string;
    movie?:Movie;
    room:string;
    datetime:Date;
    format:string;
    bought:number;
    
}

