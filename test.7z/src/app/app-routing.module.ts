import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MovieSessionListComponent } from './movies/movie-session-list/movie-session-list.component';
import { NotFoundComponent } from './errors/not-found/not-found.component';
import { MovieComponent } from './movies/movie/movie.component';


const routes: Routes = [
  { path: '', component: MovieSessionListComponent },
  { path: "movie/:id", component: MovieComponent},
  { path: '**', component: NotFoundComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
