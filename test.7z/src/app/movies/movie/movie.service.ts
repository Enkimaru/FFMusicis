import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

import { Movie } from "./movie";
import { MovieSession } from '../movie-session/movie-session';

import MovieSessions from '../../../assets/MovieSessions.json';

const API = 'http://localhost:3000';

@Injectable({ providedIn: 'root' })
export class MovieService {

    constructor(private http: HttpClient) {}

    listMovieSessions(){
        return MovieSessions;
    }
}
