import { MovieSession } from '../movie-session/movie-session';

export class Movie {
    title:string;
    director:string;
    synopsis:string;
    producer:string;
    poster:string;  
    sessions?: MovieSession[];
}

