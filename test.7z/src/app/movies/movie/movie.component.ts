import { Component, Input, OnInit } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'app-movie',
    templateUrl: 'movie.component.html',
    styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit{
    @Input() teste = '';

    testeNaTela = '';
    
    constructor(
        private activatedRoute: ActivatedRoute
    ) { }

    ngOnInit(): void {
        this.testeNaTela = this.activatedRoute.snapshot.params.id;

    }
}