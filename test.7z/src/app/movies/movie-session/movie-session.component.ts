import { Component, OnInit, Input } from '@angular/core';
import { MovieSession } from './movie-session';

@Component({
  selector: 'app-movie-session',
  templateUrl: './movie-session.component.html',
  styleUrls: ['./movie-session.component.css']
})
export class MovieSessionComponent implements OnInit {

  @Input() movieSession: MovieSession[] = [];
  
  constructor() { }

  ngOnInit() {
  }

}
