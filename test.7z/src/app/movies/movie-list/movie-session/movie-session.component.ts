import { Component, OnInit, Input } from '@angular/core';
import { Movie } from '../../movie/movie';

@Component({
  selector: 'app-movie-session',
  templateUrl: './movie-session.component.html',
  styleUrls: ['./movie-session.component.css']
})
export class MovieSessionComponent implements OnInit {

  @Input() movies: Movie[] = [];
  rows: any[] = [];
  
  constructor() { }

  ngOnInit() {
  }

}
