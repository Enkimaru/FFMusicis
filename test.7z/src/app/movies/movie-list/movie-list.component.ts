import { Component, OnInit } from '@angular/core';
import { MovieService } from '../movie/movie.service';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../movie/movie';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
  movies: Movie[] = []; 
  
  constructor(private movieService: MovieService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
      const userName = this.activatedRoute.snapshot.params.userName;

      this.movieService
        .listFromUser(userName)
        .subscribe(movies => this.movies = movies);
  }
}
