import { NgModule } from "@angular/core";

import { MovieComponent } from "./movie/movie.component";
import { HttpClientModule } from "@angular/common/http";
import { MovieListComponent } from './movie-list/movie-list.component';
import { CommonModule } from "@angular/common";
import { MovieFormComponent } from './movie-form/movie-form.component';
import { MovieSessionComponent } from './movie-list/movie-session/movie-session.component';

@NgModule({
    declarations: [ MovieComponent, MovieListComponent, MovieFormComponent, MovieSessionComponent ],
    imports: [ HttpClientModule,
    CommonModule ]
})
export class MoviesModule {}