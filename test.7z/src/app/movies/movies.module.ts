import { NgModule } from "@angular/core";

import { MovieComponent } from "./movie/movie.component";
import { HttpClientModule } from "@angular/common/http";
import { MovieSessionListComponent } from './movie-session-list/movie-session-list.component';
import { CommonModule } from "@angular/common";
import { MovieSessionComponent } from './movie-session/movie-session.component';

@NgModule({
    declarations: [ MovieComponent, MovieSessionListComponent, MovieSessionComponent ],
    imports: [ HttpClientModule,
    CommonModule ]
})
export class MoviesModule {}