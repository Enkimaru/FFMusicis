import MovieFromAPI from "./moviefromapi";

export default class MovieResponse {

    titulo: string;
    diretor: string;
    sinopse: string;
    produtor: string;
    cartaz: string; 
    id: number;

    constructor(movie: MovieFromAPI, cartaz: string) {
        this.titulo = movie.title;
        this.sinopse = movie.opening_crawl;
        this.diretor = movie.director;
        this.cartaz = cartaz;
        this.produtor = movie.producer;
    }
}