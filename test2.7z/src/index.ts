import App from './app';
import MovieController from './controllers/movies.controller'
 
const app = new App(
  [
    new MovieController(),
  ],
  process.env.PORT || 3001,
);
 
app.listen();