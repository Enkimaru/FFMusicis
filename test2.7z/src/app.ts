import * as express from 'express';
 
class App {
  public app: express.Application;
  public port: number;
 
  constructor(controllers, port) {
    this.app = express();
    this.port = port;
 
    
    this.initializeControllers(controllers);
    this.initializeMiddlewares();
  }
 
  private initializeMiddlewares() {
    this.app.use('/*', function(request, response) { 
      response.json({error: "Page not found", status: 404});
    });
    
  }
 
  private initializeControllers(controllers) {
    controllers.forEach((controller) => {
      this.app.use('/api/', controller.router);
    });
  }
 
  public listen() {
    this.app.listen(this.port, () => {
      console.log(`App listening on the port ${this.port}`);
    });
  }
}
 
export default App;