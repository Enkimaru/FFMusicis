import * as express from 'express';

import MoviesService from '../services/movies.service';
import MovieResponse from '../models/movieresponse';
import MovieFromAPI from '../models/moviefromapi';
 
export default class MoviesController {
  public path = '/movies';
  public router = express.Router();
  public moviesService = new MoviesService();
 
  
 
  constructor() {
    this.intializeRoutes();
  }
 
  public intializeRoutes() {
    this.router.get(this.path, this.getAllMovies);
    this.router.get(`${this.path}/:id`, this.getMovieById);
  }
 
  getAllMovies = async (request: express.Request, response: express.Response) => {
    try {
      let resp = await this.moviesService.getAllMovies();
      resp.data.results as MovieFromAPI[];

      let movieList = [];

      resp.data.results.forEach(movie => {
        let cartaz = "url";
        movieList.push(new MovieResponse(movie, cartaz));
      });

      response.send(movieList);
    } catch (error) {
     
      if (404 === error.response.status) {
        response.json({error: "Movies not found.", status: error.response.status});
      }
    }
  }
 
   getMovieById = async (request: express.Request, response: express.Response) => {
    try {
      let resp = await this.moviesService.getMovieById(request.params.id);
      
      let cartaz = this.moviesService.getMoviePoster(resp.data.episode_id - 1);
      
      response.send(new MovieResponse(resp.data, cartaz));
    } catch (error) {
      if(404 === error.response.status) {
        response.json({error: "Movie not found.", status: error.response.status});
      }
    }
  }
}